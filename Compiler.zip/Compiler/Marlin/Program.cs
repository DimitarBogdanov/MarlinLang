﻿using Marlin.Parser.Lexing;
using Marlin.Parser.Trees;
using System;
using System.IO;

namespace Marlin
{
    class Program
    {
        public static bool DEBUG_MODE { get; private set; } = false;

        public static void Main(string[] args)
        {
            ParseOptions(args);
        }

        private static void ParseOptions(string[] args)
        {
            CommandOptions options = new CommandOptions(args);

            DEBUG_MODE = options.HasOption("--debug");
        }
    }
}
