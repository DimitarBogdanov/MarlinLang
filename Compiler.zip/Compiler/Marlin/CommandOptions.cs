﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marlin
{
    public class CommandOptions
    {
        private List<string> arguments;

        public CommandOptions(string[] args)
        {
            arguments = args.ToList();
        }

        public bool HasOption(string option)
        {
            foreach (string str in arguments)
            {
                if (str.ToLower() == option)
                {
                    return true;
                }
            }
            return false;
        }
        
        public string ValueOf(string option)
        {
            for (int i = 0; i < arguments.Count; i++)
            {
                if (arguments[i].ToLower() == option)
                {
                    try
                    {
                        return arguments[i + 1];
                    } catch (Exception)
                    {
                        return "";
                    }
                }
            }

            return null;
        }
    }
}
