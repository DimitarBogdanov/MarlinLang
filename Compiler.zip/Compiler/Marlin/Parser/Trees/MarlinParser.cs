﻿namespace Marlin.Parser.Lexing
{
    public class MarlinParser
    {
        
    }
}
