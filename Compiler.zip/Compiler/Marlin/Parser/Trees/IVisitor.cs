﻿namespace Marlin.Parser.Trees
{
    public interface IVisitor
    {
        
    }
}
